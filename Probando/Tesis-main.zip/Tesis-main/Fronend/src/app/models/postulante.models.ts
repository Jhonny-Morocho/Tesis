
export class PostulanteModel{
    nombre:string;
    apellido:string;
    cedula:string;
    telefono:string;
    estado:Number;
    genero:Number;
    observaciones:string;
    fecha_nacimiento:string;
    direccion_domicilio:string;
    external_es:string
}