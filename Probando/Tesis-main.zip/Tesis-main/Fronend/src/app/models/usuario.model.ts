
export class UsuarioModel{
    correo:string;
    password:string;
    tipoUsuario:Number;
    estado:Number;
    external_us:string;

}