import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tareas-realizadas',
  templateUrl: './tareas-realizadas.component.html'
})
export class TareasRealizadasComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
