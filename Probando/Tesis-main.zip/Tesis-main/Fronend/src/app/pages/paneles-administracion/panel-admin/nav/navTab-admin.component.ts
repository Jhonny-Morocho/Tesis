import { Component, OnInit } from '@angular/core';
// importa utomaticamente el ingForm
import { NgForm } from '@angular/forms';

@Component({
  selector: 'navTab-admin',
  templateUrl: './navTab-admin.component.html'
})
export class PanelAdminComponent implements OnInit {
  
  constructor() { }

  ngOnInit() {


  }

}
