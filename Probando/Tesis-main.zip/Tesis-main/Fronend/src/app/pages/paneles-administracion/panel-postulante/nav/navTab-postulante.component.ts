import { Component, OnInit } from '@angular/core';
// importa utomaticamente el ingForm
import { NgForm } from '@angular/forms';

@Component({
  selector: 'navTab-postulante',
  templateUrl: './navTab-postulante.component.html'
})
export class PanelPostulanteComponent implements OnInit {
  
  constructor() { }

  ngOnInit() {


  }

}
