import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registro-empleador',
  templateUrl: './registro-empleador.component.html'
})
export class RegistroEmpleadorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
